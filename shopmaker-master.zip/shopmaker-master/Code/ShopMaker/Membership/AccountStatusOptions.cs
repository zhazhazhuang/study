﻿namespace ShopMaker.Membership
{
	public enum AccountStatusOptions : int
	{
		Active,
		Blocked,
		Expired,
		Unverified,
	}
}
