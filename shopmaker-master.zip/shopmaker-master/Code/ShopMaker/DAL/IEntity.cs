﻿using System;

namespace ShopMaker.DAL
{
    public interface IEntity
    {
        Guid ID { get; set; }
    }
}
